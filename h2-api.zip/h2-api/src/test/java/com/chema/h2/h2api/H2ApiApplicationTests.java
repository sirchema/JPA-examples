package com.chema.h2.h2api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class H2ApiApplicationTests {

	@Test
	void contextLoads() {
	}

}

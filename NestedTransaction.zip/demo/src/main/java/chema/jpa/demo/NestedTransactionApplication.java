package chema.jpa.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NestedTransactionApplication {

	public static void main(String[] args) {
		SpringApplication.run(NestedTransactionApplication.class, args);
	}

}
